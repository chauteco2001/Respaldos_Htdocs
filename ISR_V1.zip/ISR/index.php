
<!DOCTYPE html>
<html>
<head>
    <title>Calculadora de ISR</title>
</head>
<body>
    <h1>Calculadora de ISR</h1>
    <form method="post" action="">
        <label for="compras">Compras:</label>
        <input type="text" name="compras" id="compras"><br>

        <label for="combustibles">Combustibles y lubricantes:</label>
        <input type="text" name="combustibles" id="combustibles"><br>

        <label for="manto_equipo">Manto de equipo:</label>
        <input type="text" name="manto_equipo" id="manto_equipo"><br>

        <label for="cuota_imss_infonavit">Cuota IMSS RVC e Infonavit:</label>
        <input type="text" name="cuota_imss_infonavit" id="cuota_imss_infonavit"><br>

        <label for="diversos">Diversos:</label>
        <input type="text" name="diversos" id="diversos"><br>

        <label for="deprestaciones">Deprestaciones:</label>
        <input type="text" name="deprestaciones" id="deprestaciones"><br>

        <label for="comisiones_bancarias">Comisiones bancarias:</label>
        <input type="text" name="comisiones_bancarias" id="comisiones_bancarias"><br>

        <label for="sueldos_salarios">Sueldos y salarios:</label>
        <input type="text" name="sueldos_salarios" id="sueldos_salarios"><br>

        <input type="submit" value="Calcular ISR">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Obtener los valores ingresados por el usuario
        $compras = floatval($_POST["compras"]);
        $combustibles = floatval($_POST["combustibles"]);
        $manto_equipo = floatval($_POST["manto_equipo"]);
        $cuota_imss_infonavit = floatval($_POST["cuota_imss_infonavit"]);
        $diversos = floatval($_POST["diversos"]);
        $deprestaciones = floatval($_POST["deprestaciones"]);
        $comisiones_bancarias = floatval($_POST["comisiones_bancarias"]);
        $sueldos_salarios = floatval($_POST["sueldos_salarios"]);

        // Calcular la suma de los ingresos gravables
        $ingresos_gravables = $compras + $combustibles + $manto_equipo + $cuota_imss_infonavit + $diversos + $deprestaciones + $comisiones_bancarias + $sueldos_salarios;

        // Realizar el cálculo del ISR para enero
        function calcularISRenero($ingresos) {
            if ($ingresos <= 746.04) {
                return 0.0192 * $ingresos;
            } elseif ($ingresos <= 6332.05) {
                return (0.064 * ($ingresos - 746.04)) + 14.32;
            } elseif ($ingresos <= 11128.01) {
                return (0.1088 * ($ingresos - 6332.05)) + 371.83;
            } elseif ($ingresos <= 12935.82) {
                return (0.16 * ($ingresos - 11128.01)) + 893.63;
            } elseif ($ingresos <= 15487.71) {
                return (0.1792 * ($ingresos - 12935.82)) + 1182.88;
            } elseif ($ingresos <= 31236.49) {
                return (0.2136 * ($ingresos - 15487.71)) + 1640.18;
            } elseif ($ingresos <= 49233.00) {
                return (0.2352 * ($ingresos - 31236.49)) + 5004.12;
            } elseif ($ingresos <= 93993.90) {
                return (0.30 * ($ingresos - 49233.01)) + 9236.89;
            } elseif ($ingresos <= 125325.20) {
                return (0.32 * ($ingresos - 93993.91)) + 22665.17;
            } elseif ($ingresos <= 375975.61) {
                return (0.34 * ($ingresos - 125325.21)) + 32691.18;
            } else {
                return (0.35 * ($ingresos - 375975.62)) + 117912.32;
            }
        }
        
        // Calcular el ISR para enero
        $isr_enero = calcularISRenero($ingresos_gravables);

        // Mostrar los resultados
        echo "Ingresos Gravables: $" . number_format($ingresos_gravables, 2) . "<br>";
        echo "ISR a pagar para enero: $" . number_format($isr_enero, 2);
    }
    ?>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Tabla ISR</title>
    <link rel="stylesheet" href="css/estilo.css">
</head>
<body>
    <div class="encabezado">
        <form>
            <h2>Selecciona un mes</h2>
            <select id="mes" onchange="mostrarTabla(this.value)">
                <option value="">selecciona un mes</option>
                <option value="1">Enero</option>
                <option value="2">Febrero</option>
                <option value="3">Marzo</option>
                <option value="4">Abril</option>
                <option value="5">Mayo</option>
                <option value="6">Junio</option>
                <option value="7">Julio</option>
                <option value="8">Agosto</option>
                <option value="9">Septiembre</option>
                <option value="10">Octubre</option>
                <option value="11">Noviembre</option>
                <option value="12">Diciembre</option>
            </select>
        </form>
    </div>

    <div id="resultado"></div>

    <script>
        
    function mostrarTabla(mes) {
        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("resultado").innerHTML = xmlhttp.responseText;
            }
        }

        xmlhttp.open("GET", `procesar.php?opcion=mostrarTabla&mes=${mes}`, true);
        xmlhttp.send();
    }

    function calcular() {  
        var sueldo = document.getElementById("SaldoBruto").value;

        var xmlhttp = new XMLHttpRequest();
        xmlhttp.onreadystatechange = function () {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                document.getElementById("resultadoCalculo").innerHTML = xmlhttp.responseText;
            }
        }

        xmlhttp.open("GET", `procesar.php?opcion=calcular&saldoBruto=${sueldo}`, true);
        xmlhttp.send();
    }
    </script>
</body>
</html>
