<?php
session_start();

// Incluye el archivo de conexión a la base de datos
include('../conexion.php');

// Obtener los datos del formulario
$nombre_usuario = $_POST['nombre_usuario'];
$clave = $_POST['clave'];

// Consulta SQL para verificar las credenciales
$sql = "SELECT * FROM login_usuarios WHERE nombre_usuario = '$nombre_usuario' AND clave = '$clave'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Las credenciales son válidas
    $_SESSION['nombre_usuario'] = $nombre_usuario;
    header("Location: index.php"); // Redirige a la página de inicio
} else {
    // Las credenciales son incorrectas
    echo "Nombre de usuario o contraseña incorrectos. Por favor, inténtalo de nuevo.";
}

$conn->close();
?>